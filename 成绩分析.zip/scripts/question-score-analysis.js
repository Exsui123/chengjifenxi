/**
 * 成绩分析系统 - 个人小题得分情况分析模块
 * 负责分析和可视化学生的小题得分情况
 */

// 当前选择的文件ID
let selectedQuestionScoreFileId = '';
// 当前选择的学生ID
let selectedQuestionScoreStudentId = '';

// 全局变量：按钮状态
let showMaxScoreBar = false; // 是否显示满分柱子，默认不显示
let sortByScoreRate = false; // 是否按得分率排序

// 等待DOM完全加载后执行
document.addEventListener('DOMContentLoaded', function() {
    initQuestionScoreAnalysisModule();
});

/**
 * 初始化个人小题得分情况分析模块
 */
function initQuestionScoreAnalysisModule() {
    // 获取文件选择下拉框
    const fileSelect = document.getElementById('questionScoreFileSelect');
    // 获取学生选择下拉框
    const studentSelect = document.getElementById('questionScoreStudentSelect');
    // 获取生成分析按钮
    const generateBtn = document.getElementById('generateQuestionScoreBtn');
    
    // 如果元素不存在，表示不在分析页面，直接返回
    if (!fileSelect || !studentSelect || !generateBtn) return;
    
    // 文件选择变化事件
    fileSelect.addEventListener('change', function() {
        selectedQuestionScoreFileId = this.value;
        
        if (selectedQuestionScoreFileId) {
            // 显示已选择文件信息
            updateQuestionScoreSelectedFileInfo();
            // 加载学生选择下拉框
            loadQuestionScoreStudentOptions();
            // 启用学生选择下拉框
            studentSelect.disabled = false;
        } else {
            // 隐藏已选择文件信息
            document.getElementById('questionScoreSelectedFileInfo').style.display = 'none';
            // 清空并禁用学生选择下拉框
            studentSelect.innerHTML = '<option value="">-- 请先选择成绩表 --</option>';
            studentSelect.disabled = true;
            // 禁用生成按钮
            generateBtn.disabled = true;
        }
    });
    
    // 学生选择变化事件
    studentSelect.addEventListener('change', function() {
        selectedQuestionScoreStudentId = this.value;
        updateGenerateQuestionScoreButtonState();
    });
    
    // 生成按钮点击事件
    generateBtn.addEventListener('click', function() {
        if (selectedQuestionScoreFileId && selectedQuestionScoreStudentId) {
            performQuestionScoreAnalysis();
        }
    });
}

/**
 * 显示个人小题得分情况分析选项
 */
function showQuestionScoreAnalysisOptions() {
    console.log('显示个人小题得分情况分析选项...');
    
    // 显示选项区域
    const optionsArea = document.getElementById('questionScoreAnalysisOptions');
    if (optionsArea) {
        console.log('找到选项区域，设置为显示');
        optionsArea.style.display = 'block';
    } else {
        console.error('未找到选项区域 questionScoreAnalysisOptions');
    }
    
    // 加载文件选择下拉框选项
    loadQuestionScoreFileOptions();
}

/**
 * 隐藏个人小题得分情况分析选项
 */
function hideQuestionScoreAnalysisOptions() {
    // 隐藏选项区域
    const optionsArea = document.getElementById('questionScoreAnalysisOptions');
    if (optionsArea) {
        optionsArea.style.display = 'none';
    }
}

/**
 * 加载文件选择下拉框选项
 */
function loadQuestionScoreFileOptions() {
    const fileSelect = document.getElementById('questionScoreFileSelect');
    if (!fileSelect) {
        console.error('找不到文件选择下拉框 questionScoreFileSelect');
        return;
    }
    
    console.log('开始加载成绩表选项...');
    
    // 清空下拉框
    fileSelect.innerHTML = '<option value="">-- 请选择成绩表 --</option>';
    
    // 获取所有文件数据
    const filesData = JSON.parse(localStorage.getItem('scoreFiles')) || [];
    console.log('从localStorage加载到的成绩表数量:', filesData.length);
    
    // 添加文件选项
    if (filesData.length === 0) {
        console.warn('没有找到成绩表数据');
        fileSelect.innerHTML += '<option value="" disabled>没有找到成绩表数据</option>';
    } else {
        filesData.forEach(file => {
            const option = document.createElement('option');
            option.value = file.id;
            option.textContent = `${file.name || '未命名'} - ${file.class || '未知班级'} (${file.date || '无日期'})`;
            fileSelect.appendChild(option);
            console.log('添加选项:', file.id, option.textContent);
        });
    }
    
    console.log('成绩表选项加载完成');
}

/**
 * 更新已选择文件信息
 */
function updateQuestionScoreSelectedFileInfo() {
    const infoContainer = document.getElementById('questionScoreSelectedFileInfo');
    const fileDetailContainer = document.getElementById('questionScoreSelectedFileDetail');
    
    if (!infoContainer || !fileDetailContainer || !selectedQuestionScoreFileId) return;
    
    // 获取文件数据
    const filesData = JSON.parse(localStorage.getItem('scoreFiles')) || [];
    const fileData = filesData.find(file => file.id === selectedQuestionScoreFileId);
    
    if (fileData) {
        // 构造文件信息HTML
        const html = `
            <p><strong>名称:</strong> ${fileData.name}</p>
            <p><strong>班级:</strong> ${fileData.class}</p>
            <p><strong>日期:</strong> ${fileData.date}</p>
        `;
        
        // 更新文件信息
        fileDetailContainer.innerHTML = html;
        infoContainer.style.display = 'block';
    } else {
        infoContainer.style.display = 'none';
    }
}

/**
 * 加载学生选择下拉框选项
 */
function loadQuestionScoreStudentOptions() {
    const studentSelect = document.getElementById('questionScoreStudentSelect');
    if (!studentSelect || !selectedQuestionScoreFileId) return;
    
    // 清空下拉框
    studentSelect.innerHTML = '<option value="">-- 请选择学生 --</option>';
    
    // 获取文件数据
    const filesData = JSON.parse(localStorage.getItem('scoreFiles')) || [];
    const fileData = filesData.find(file => file.id === selectedQuestionScoreFileId);
    
    if (fileData && fileData.data && fileData.data.length > 1) {
        // 查找学号和姓名列的索引
        const headers = fileData.data[0];
        const idColumnIndex = findStudentIdColumnIndex(headers);
        const nameColumnIndex = findStudentNameColumnIndex(headers);
        
        if (idColumnIndex !== -1 && nameColumnIndex !== -1) {
            // 提取学生数据
            const students = fileData.data.slice(1).map(row => ({
                id: row[idColumnIndex],
                name: row[nameColumnIndex]
            }));
            
            // 添加学生选项
            students.forEach(student => {
                const option = document.createElement('option');
                option.value = student.id;
                option.textContent = `${student.name} (${student.id})`;
                studentSelect.appendChild(option);
            });
        }
    }
}

/**
 * 更新生成按钮状态
 */
function updateGenerateQuestionScoreButtonState() {
    const generateBtn = document.getElementById('generateQuestionScoreBtn');
    if (!generateBtn) return;
    
    // 如果已选择文件和学生，启用生成按钮
    generateBtn.disabled = !(selectedQuestionScoreFileId && selectedQuestionScoreStudentId);
}

/**
 * 执行个人小题得分情况分析
 */
function performQuestionScoreAnalysis() {
    // 获取文件数据
    const filesData = JSON.parse(localStorage.getItem('scoreFiles')) || [];
    const fileData = filesData.find(file => file.id === selectedQuestionScoreFileId);
    
    if (!fileData) return;
    
    // 清空分析结果区域
    clearAnalysisResult();
    
    // 查找学号和姓名列的索引
    const headers = fileData.data[0];
    const idColumnIndex = findStudentIdColumnIndex(headers);
    const nameColumnIndex = findStudentNameColumnIndex(headers);
    
    if (idColumnIndex === -1 || nameColumnIndex === -1) {
        showMessage('无法识别学号或姓名列', 'error');
        return;
    }
    
    // 查找小题分数列
    const questionColumns = findQuestionScoreColumns(headers);
    
    if (questionColumns.length === 0) {
        showMessage('未找到小题分数列，请确保成绩表中包含类似"小题1"、"题1"等列名', 'error');
        return;
    }
    
    // 查找学生数据
    const studentRow = fileData.data.slice(1).find(row => row[idColumnIndex] === selectedQuestionScoreStudentId);
    
    if (!studentRow) {
        showMessage('未找到所选学生的数据', 'error');
        return;
    }
    
    // 生成个人小题得分情况分析结果
    generateQuestionScoreAnalysisResult(studentRow, headers, questionColumns, nameColumnIndex);
}

/**
 * 查找小题分数列
 * @param {Array} headers - 表头行
 * @returns {Array} 小题分数列的索引和列名数组
 */
function findQuestionScoreColumns(headers) {
    const questionColumns = [];
    
    // 查找包含"小题"、"题"等关键词的列
    headers.forEach((header, index) => {
        if (
            (typeof header === 'string' && (
                header.includes('小题') || 
                header.includes('题') || 
                /Q\d+/.test(header) || // 匹配Q1, Q2等格式
                /第\s*\d+\s*题/.test(header) || // 匹配"第1题"、"第 1 题"等格式
                /题目\s*\d+/.test(header) // 匹配"题目1"、"题目 1"等格式
            )) ||
            (typeof header === 'number' && index > 2) // 如果是纯数字且不是学号或姓名列，也可能是题号
        ) {
            questionColumns.push({
                index: index,
                name: header
            });
        }
    });
    
    // 如果没有找到明确的小题列，尝试使用除了学号、姓名和总分外的所有其他列
    if (questionColumns.length === 0) {
        // 查找可能的总分列
        const totalScoreIndex = headers.findIndex(header => 
            typeof header === 'string' && (
                header.includes('总分') || 
                header.includes('总成绩') || 
                header.includes('成绩') || 
                header === '分数'
            )
        );
        
        // 获取学号和姓名列的索引
        const idIndex = findStudentIdColumnIndex(headers);
        const nameIndex = findStudentNameColumnIndex(headers);
        
        // 除了学号、姓名和总分外的所有列都可能是小题列
        headers.forEach((header, index) => {
            if (
                index !== idIndex && 
                index !== nameIndex && 
                index !== totalScoreIndex &&
                index > 1 // 跳过可能的序号列
            ) {
                questionColumns.push({
                    index: index,
                    name: header
                });
            }
        });
    }
    
    // 按照题目序号排序（假设题目名称中包含数字）
    return questionColumns.sort((a, b) => {
        const numA = parseInt(String(a.name).replace(/[^0-9]/g, '')) || 0;
        const numB = parseInt(String(b.name).replace(/[^0-9]/g, '')) || 0;
        return numA - numB;
    });
}

/**
 * 生成个人小题得分情况分析结果
 * @param {Array} studentRow - 学生数据行
 * @param {Array} headers - 表头行
 * @param {Array} questionColumns - 小题分数列的信息
 * @param {number} nameColumnIndex - 姓名列的索引
 */
function generateQuestionScoreAnalysisResult(studentRow, headers, questionColumns, nameColumnIndex) {
    // 获取分析结果容器
    const resultContainer = document.getElementById('analysisResult');
    if (!resultContainer) return;
    
    // 获取学生姓名
    const studentName = studentRow[nameColumnIndex];
    
    // 按钮区域HTML
    const buttonHTML = `
        <div id="questionScoreChartBtns" style="margin-bottom: 1rem; display: flex; gap: 1rem;">
            <label style="cursor:pointer;" title="显示/隐藏满分柱子">
                <input type="checkbox" id="toggleMaxScoreBar" ${showMaxScoreBar ? 'checked' : ''} /> 显示满分
            </label>
            <label style="cursor:pointer;" title="按得分率排序并显示百分比">
                <input type="checkbox" id="toggleSortByScoreRate" ${sortByScoreRate ? 'checked' : ''} /> 使用得分率模式
            </label>
        </div>
    `;
    
    // 创建分析结果内容
    const resultHTML = `
        <div class="analysis-result-container">
            <h3 class="analysis-title">个人小题得分情况分析 - ${studentName}</h3>
            <div class="analysis-content">
                ${buttonHTML}
                <div class="question-score-chart-container">
                    <canvas id="questionScoreChart"></canvas>
                </div>
                <div class="question-score-summary">
                    <h4>得分情况概述</h4>
                    <div id="questionScoreSummary"></div>
                </div>
            </div>
        </div>
    `;
    
    // 更新分析结果容器
    resultContainer.innerHTML = resultHTML;
    
    /**
     * 获取小题的满分值（如果有的话）
     * @param {number} columnIndex - 列索引
     * @returns {number} 满分值，如果不确定则返回10
     */
    function getQuestionMaxScore(columnIndex) {
        try {
            // 获取小题的名称
            const questionName = headers[columnIndex];
            
            // 解析小题名称中的分数信息（如果存在）
            if (typeof questionName === 'string') {
                // 从格式为"小题X(20分)"或"小题X（20分）"的名称中提取分数
                const scoreMatch = questionName.match(/\((\d+)分\)|\（(\d+)分\）/);
                if (scoreMatch) {
                    // 提取第一个捕获组或第二个捕获组中的数字（取决于使用的是英文还是中文括号）
                    return parseInt(scoreMatch[1] || scoreMatch[2]);
                }
            }
            
            // 如果小题名称中包含分值信息（如"小题7(20分)"），从中提取
            // 正则表达式匹配括号内的数字并提取
            const questionStr = String(questionName || '');
            const maxScoreMatch = questionStr.match(/\((\d+)\s*分\)|\（(\d+)\s*分\）/);
            if (maxScoreMatch) {
                return parseInt(maxScoreMatch[1] || maxScoreMatch[2]);
            }
            
            // 如果小题名称不含分值信息但包含数字（例如：小题7(20分)），尝试提取
            const scoreInNameMatch = /小题\s*(\d+)\s*(?:\(|（)(\d+)(?:分)(?:\)|）)/i.exec(questionStr);
            if (scoreInNameMatch && scoreInNameMatch[2]) {
                return parseInt(scoreInNameMatch[2]);
            }
            
            // 根据列名中的提示获取满分值
            if (questionStr.includes('小题7') || questionStr.includes('题7') || questionStr.includes('第7题')) {
                return 20; // 小题7的满分是20分
            } else if (questionStr.includes('小题6') || questionStr.includes('题6') || questionStr.includes('第6题')) {
                return 20; // 小题6的满分是20分
            } else if (questionStr.includes('小题5') || questionStr.includes('题5') || questionStr.includes('第5题')) {
                return 15; // 小题5的满分是15分
            } else if (questionStr.includes('小题4') || questionStr.includes('题4') || questionStr.includes('第4题')) {
                return 15; // 小题4的满分是15分
            } else {
                // 默认其他小题满分为10分
                return 10;
            }
        } catch (error) {
            console.error('获取满分值出错:', error);
            return 10; // 出错时返回默认值10
        }
    }
    
    // 收集小题分数数据
    let questionScores = [];
    try {
        questionScores = questionColumns.map(column => {
            const score = parseFloat(studentRow[column.index]) || 0;
            // 尝试从其他行获取各小题的满分值
            const maxScore = getQuestionMaxScore(column.index);
            console.log(`小题 ${column.name}: 得分=${score}, 满分=${maxScore}`);
            return {
                question: column.name,
                score: score,
                maxScore: maxScore
            };
        });
    } catch (error) {
        console.error('收集小题分数数据出错:', error);
        showMessage('收集小题分数数据出错:' + error.message, 'error');
    }
    
    // 保存原始顺序
    const originalOrder = [...questionScores];
    
    // 排序处理
    if (sortByScoreRate) {
        questionScores = [...questionScores].sort((a, b) => (b.score / b.maxScore) - (a.score / a.maxScore));
    }
    
    try {
        // 渲染小题得分图表
        renderQuestionScoreChart(questionScores, showMaxScoreBar, sortByScoreRate);
        
        // 生成得分概述
        generateQuestionScoreSummary(questionScores);
    } catch (error) {
        console.error('渲染图表或生成概述时出错:', error);
        showMessage('图表渲染失败:' + error.message, 'error');
    }
    
    // 绑定按钮事件
    setTimeout(() => {
        try {
            const maxScoreBtn = document.getElementById('toggleMaxScoreBar');
            const sortBtn = document.getElementById('toggleSortByScoreRate');
            
            if (maxScoreBtn) {
                maxScoreBtn.onchange = function() {
                    showMaxScoreBar = this.checked;
                    // 重新渲染整个分析区域，保证按钮、图表、概述都同步
                    generateQuestionScoreAnalysisResult(studentRow, headers, questionColumns, nameColumnIndex);
                };
            }
            
            if (sortBtn) {
                sortBtn.onchange = function() {
                    sortByScoreRate = this.checked;
                    // 重新渲染整个分析区域，保证按钮、图表、概述都同步
                    generateQuestionScoreAnalysisResult(studentRow, headers, questionColumns, nameColumnIndex);
                };
            }
        } catch (error) {
            console.error('绑定按钮事件出错:', error);
        }
    }, 100);
}

/**
 * 渲染小题得分图表
 * @param {Array} questionScores - 小题分数数据
 * @param {boolean} showMaxScoreBar - 是否显示满分柱子
 * @param {boolean} useScoreRate - 是否使用得分率模式（Y轴显示百分比）
 */
function renderQuestionScoreChart(questionScores, showMaxScoreBar = true, useScoreRate = false) {
    const canvas = document.getElementById('questionScoreChart');
    if (!canvas) {
        console.error('找不到图表Canvas元素');
        return;
    }
    
    console.log('开始渲染图表，数据:', questionScores, '显示满分:', showMaxScoreBar, '使用得分率模式:', useScoreRate);
    
    try {
        // 准备图表数据
        const labels = questionScores.map(item => {
            // 如果小题名称中已经包含分值信息，直接使用
            if (String(item.question).includes('分)') || String(item.question).includes('分）')) {
                return item.question;
            }
            // 否则，添加满分信息到标签
            return `${item.question}(${item.maxScore}分)`;
        });
        
        // 根据模式选择要显示的数据
        let scores, maxValues;
        if (useScoreRate) {
            // 使用百分比模式：分数表示得分率（0-100%）
            scores = questionScores.map(item => 
                item.maxScore > 0 ? (item.score / item.maxScore * 100) : 0
            );
            maxValues = questionScores.map(() => 100); // 满分统一为100%
        } else {
            // 使用原始分数模式
            scores = questionScores.map(item => item.score);
            maxValues = questionScores.map(item => item.maxScore);
        }
        
        // 计算得分率（用于显示在标签和提示中）
        const scoreRates = questionScores.map(item => 
            item.maxScore > 0 ? (item.score / item.maxScore * 100).toFixed(1) + '%' : 'N/A'
        );
        
        // 计算Y轴自适应刻度间隔
        const maxValue = useScoreRate ? 100 : Math.max(...maxValues);
        const minValue = useScoreRate ? 0 : Math.min(...scores);
        // 期望的最大刻度数量
        const maxTicks = 12;
        let stepSize;
        if (useScoreRate) {
            // 百分比模式下使用固定的刻度间隔
            stepSize = 10; // 每10%一个刻度
        } else {
            // 原始分数模式下动态计算刻度间隔
            stepSize = Math.ceil((maxValue - minValue) / maxTicks);
            if (stepSize < 1) stepSize = 1;
        }
        
        // 组装datasets
        const datasets = [{
            label: useScoreRate ? '得分率' : '得分',
            data: scores,
            backgroundColor: questionScores.map(item => {
                const rate = item.maxScore > 0 ? item.score / item.maxScore : 0;
                if (rate >= 0.8) return 'rgba(75, 192, 192, 0.7)'; // 得分率高
                if (rate >= 0.6) return 'rgba(54, 162, 235, 0.7)'; // 得分率中等
                return 'rgba(255, 99, 132, 0.7)'; // 得分率低
            }),
            borderColor: 'rgba(0, 0, 0, 0.1)',
            borderWidth: 1
        }];
        
        if (showMaxScoreBar) {
            datasets.push({
                label: useScoreRate ? '100%' : '满分',
                data: maxValues,
                backgroundColor: 'rgba(0, 0, 0, 0.05)',
                borderColor: 'rgba(0, 0, 0, 0.1)',
                borderWidth: 1
            });
        }
        
        // 创建柱状图
        const chart = new Chart(canvas, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: datasets
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        beginAtZero: true,
                        // 调整X轴最大值
                        suggestedMax: useScoreRate ? 105 : Math.max(...maxValues) * 1.1, // 添加一些边距
                        title: {
                            display: true,
                            text: '题目',
                            font: {
                                size: 14
                            }
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: useScoreRate ? '得分率(%)' : '分数',
                            font: {
                                size: 14
                            }
                        },
                        // 自适应间隔
                        ticks: {
                            stepSize: stepSize
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            afterLabel: function(context) {
                                const index = context.dataIndex;
                                if (context.datasetIndex === 0) { // 只在显示得分的数据集中显示额外信息
                                    if (useScoreRate) {
                                        // 如果是百分比模式，显示原始分数
                                        return `原始分数: ${questionScores[index].score}/${questionScores[index].maxScore}`;
                                    } else {
                                        // 如果是分数模式，显示得分率
                                        return `得分率: ${scoreRates[index]}`;
                                    }
                                }
                                return '';
                            }
                        }
                    },
                    datalabels: {
                        display: function(context) {
                            return context.datasetIndex === 0; // 只在得分的数据集上显示标签
                        },
                        formatter: function(value, context) {
                            const index = context.dataIndex;
                            if (useScoreRate) {
                                // 百分比模式：显示得分率和原始分数
                                return `${value.toFixed(1)}% (${questionScores[index].score}/${questionScores[index].maxScore})`;
                            } else {
                                // 分数模式：显示分数和得分率
                                return `${value} (${scoreRates[index]})`;
                            }
                        },
                        color: 'black',
                        anchor: 'end',
                        align: 'end',
                        offset: 4,
                        font: {
                            weight: 'bold'
                        }
                    },
                    legend: {
                        position: 'top'
                    },
                    title: {
                        display: true,
                        text: useScoreRate ? '个人小题得分率情况' : '个人小题得分情况',
                        font: {
                            size: 18
                        }
                    }
                }
            }
        });
        
        // 调整图表容器高度
        const container = document.querySelector('.question-score-chart-container');
        if (container) {
            // 设置最大高度，超出部分可滚动
            container.style.maxHeight = '600px';
            container.style.overflowY = 'auto';
            // 根据题目数量调整高度，每题至少40px高度
            const minHeight = Math.max(400, questionScores.length * 40);
            container.style.height = minHeight + 'px';
        }
    } catch (error) {
        console.error('图表渲染错误:', error);
        // 在canvas上显示错误信息，这样用户可以看到
        const ctx = canvas.getContext('2d');
        ctx.font = '14px Arial';
        ctx.fillStyle = 'red';
        ctx.fillText('图表渲染失败: ' + error.message, 10, 50);
    }
}

/**
 * 生成小题得分概述
 * @param {Array} questionScores - 小题分数数据
 */
function generateQuestionScoreSummary(questionScores) {
    const summaryContainer = document.getElementById('questionScoreSummary');
    if (!summaryContainer) return;
    
    // 计算总分和总满分
    const totalScore = questionScores.reduce((sum, item) => sum + item.score, 0);
    const totalMaxScore = questionScores.reduce((sum, item) => sum + item.maxScore, 0);
    const totalScoreRate = totalMaxScore > 0 ? (totalScore / totalMaxScore * 100).toFixed(1) + '%' : 'N/A';
    
    // 找出得分率最高和最低的题目
    const sortedByRate = [...questionScores].filter(item => item.maxScore > 0)
        .sort((a, b) => (b.score / b.maxScore) - (a.score / a.maxScore));
    
    const bestQuestions = sortedByRate.slice(0, 3);
    const worstQuestions = sortedByRate.slice(-3).reverse();
    
    // 获取总体评级
    const rateValue = totalMaxScore > 0 ? (totalScore / totalMaxScore * 100) : 0;
    let ratingText, ratingClass;
    if (rateValue >= 90) {
        ratingText = "优秀";
        ratingClass = "excellent";
    } else if (rateValue >= 75) {
        ratingText = "良好";
        ratingClass = "good";
    } else if (rateValue >= 60) {
        ratingText = "及格";
        ratingClass = "pass";
    } else {
        ratingText = "需加强";
        ratingClass = "fail";
    }
    
    // 为得分概述添加样式
    const style = document.createElement('style');
    style.textContent = `
        .summary-container {
            font-family: "Microsoft YaHei", "Segoe UI", sans-serif;
            color: #333;
        }
        .summary-card {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 20px;
            overflow: hidden;
        }
        .card-header {
            padding: 12px 20px;
            border-bottom: 1px solid #f0f0f0;
            display: flex;
            align-items: center;
        }
        .card-header-icon {
            margin-right: 10px;
            color: #1976d2;
            font-size: 20px;
        }
        .card-title {
            font-size: 16px;
            font-weight: bold;
            margin: 0;
            color: #333;
        }
        .card-body {
            padding: 20px;
        }
        .summary-highlight {
            border-left: 3px solid #1976d2;
            background-color: #f5f9fd;
            padding: 15px 20px;
            margin-bottom: 15px;
            border-radius: 4px;
        }
        .highlight-text {
            margin: 0;
            line-height: 1.5;
        }
        .highlight-text strong {
            color: #1976d2;
        }
        .score-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-top: 20px;
        }
        .score-card {
            flex: 1;
            min-width: 250px;
            border-radius: 8px;
            padding: 15px;
            position: relative;
        }
        .strength-card {
            background-color: rgba(76, 175, 80, 0.1);
            border: 1px solid rgba(76, 175, 80, 0.3);
        }
        .weakness-card {
            background-color: rgba(244, 67, 54, 0.1);
            border: 1px solid rgba(244, 67, 54, 0.3);
        }
        .card-icon {
            position: absolute;
            top: 15px;
            right: 15px;
            font-size: 24px;
            opacity: 0.2;
        }
        .strength-card .card-icon {
            color: #4caf50;
        }
        .weakness-card .card-icon {
            color: #f44336;
        }
        .score-card-title {
            font-size: 16px;
            font-weight: bold;
            margin-top: 0;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid rgba(0,0,0,0.1);
        }
        .strength-card .score-card-title {
            color: #2e7d32;
        }
        .weakness-card .score-card-title {
            color: #c62828;
        }
        .score-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        .question-info {
            display: flex;
            flex-direction: column;
        }
        .question-name {
            font-weight: bold;
            margin-bottom: 3px;
        }
        .score-value {
            white-space: nowrap;
            font-weight: bold;
            margin-left: 15px;
        }
        .score-bar-container {
            height: 6px;
            background-color: rgba(0,0,0,0.05);
            border-radius: 3px;
            margin-top: 5px;
            width: 100%;
        }
        .score-bar {
            height: 100%;
            border-radius: 3px;
        }
        .score-high {
            background-color: #4caf50;
        }
        .score-medium {
            background-color: #2196f3;
        }
        .score-low {
            background-color: #f44336;
        }
        .suggestion-list {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-top: 10px;
        }
        .suggestion-item {
            flex: 1;
            min-width: 200px;
            background-color: #fff;
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            border-left: 3px solid #1976d2;
        }
        .suggestion-item h5 {
            margin-top: 0;
            margin-bottom: 10px;
            font-size: 15px;
            color: #1976d2;
            display: flex;
            align-items: center;
        }
        .suggestion-item h5:before {
            content: '';
            display: inline-block;
            width: 18px;
            height: 18px;
            margin-right: 8px;
            background-size: contain;
            background-repeat: no-repeat;
            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%231976d2"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm2.07-7.75l-.9.92C13.45 12.9 13 13.5 13 15h-2v-.5c0-1.1.45-2.1 1.17-2.83l1.24-1.26c.37-.36.59-.86.59-1.41 0-1.1-.9-2-2-2s-2 .9-2 2H8c0-2.21 1.79-4 4-4s4 1.79 4 4c0 .88-.36 1.68-.93 2.25z"/></svg>');
        }
        .suggestion-item p {
            margin: 0;
            font-size: 14px;
            line-height: 1.5;
            color: #555;
        }
    `;
    summaryContainer.appendChild(style);
    
    // 创建成绩总结HTML
    const summaryHTML = `
        <div class="summary-container">
            <!-- 总体概述卡片 -->
            <div class="summary-card">
                <div class="card-header">
                    <div class="card-header-icon">📊</div>
                    <h3 class="card-title">得分情况概述</h3>
                </div>
                <div class="card-body">
                    <div class="summary-highlight">
                        <p class="highlight-text">
                            总得分：<strong>${totalScore}/${totalMaxScore}</strong>，得分率：<strong>${totalScoreRate}</strong>，
                            整体表现<strong>${ratingText}</strong>。${
                                rateValue >= 75 ? 
                                '大部分题目掌握良好，可以继续保持。' : 
                                '部分题目需要加强，建议重点复习。'
                            }
                        </p>
                    </div>
                    
                    <!-- 得分卡片网格 -->
                    <div class="score-grid">
                        <!-- 掌握较好的题目卡片 -->
                        <div class="score-card strength-card">
                            <div class="card-icon">⭐</div>
                            <h4 class="score-card-title">掌握较好的题目</h4>
                            <div class="strength-list">
                                ${bestQuestions.map(item => {
                                    const rate = (item.score / item.maxScore * 100).toFixed(1);
                                    let questionText = item.question;
                                    if (!String(questionText).includes('分)') && !String(questionText).includes('分）')) {
                                        questionText = `${questionText}(${item.maxScore}分)`;
                                    }
                                    
                                    const barClass = rate >= 90 ? 'score-high' : (rate >= 70 ? 'score-medium' : 'score-low');
                                    
                                    return `
                                        <div class="score-item">
                                            <div class="question-info">
                                                <div class="question-name">${questionText}</div>
                                                <div class="score-bar-container">
                                                    <div class="score-bar ${barClass}" style="width: ${rate}%"></div>
                                                </div>
                                            </div>
                                            <div class="score-value">${item.score}/${item.maxScore} (${rate}%)</div>
                                        </div>
                                    `;
                                }).join('')}
                            </div>
                        </div>
                        
                        <!-- 需要加强的题目卡片 -->
                        <div class="score-card weakness-card">
                            <div class="card-icon">⚠️</div>
                            <h4 class="score-card-title">需要加强的题目</h4>
                            <div class="weakness-list">
                                ${worstQuestions.map(item => {
                                    const rate = (item.score / item.maxScore * 100).toFixed(1);
                                    let questionText = item.question;
                                    if (!String(questionText).includes('分)') && !String(questionText).includes('分）')) {
                                        questionText = `${questionText}(${item.maxScore}分)`;
                                    }
                                    
                                    const barClass = rate >= 90 ? 'score-high' : (rate >= 70 ? 'score-medium' : 'score-low');
                                    
                                    return `
                                        <div class="score-item">
                                            <div class="question-info">
                                                <div class="question-name">${questionText}</div>
                                                <div class="score-bar-container">
                                                    <div class="score-bar ${barClass}" style="width: ${rate}%"></div>
                                                </div>
                                            </div>
                                            <div class="score-value">${item.score}/${item.maxScore} (${rate}%)</div>
                                        </div>
                                    `;
                                }).join('')}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- 学习建议卡片 -->
            <div class="summary-card">
                <div class="card-header">
                    <div class="card-header-icon">💡</div>
                    <h3 class="card-title">学习建议</h3>
                </div>
                <div class="card-body">
                    <div class="suggestion-list">
                        <div class="suggestion-item">
                            <h5>保持优势学习态势</h5>
                            <p>继续保持对掌握较好题目类型的复习频率，并尝试挑战更高难度的题目：${bestQuestions.map(item => {
                                let questionText = item.question;
                                if (!String(questionText).includes('分)') && !String(questionText).includes('分）')) {
                                    questionText = `${questionText}(${item.maxScore}分)`;
                                }
                                return questionText;
                            }).join('、')}。</p>
                        </div>
                        
                        <div class="suggestion-item">
                            <h5>增强知识连贯性</h5>
                            <p>成绩有一定波动，建议重点对低分题目进行知识点之间的联系，及时复习巩固：${worstQuestions.map(item => {
                                let questionText = item.question;
                                if (!String(questionText).includes('分)') && !String(questionText).includes('分）')) {
                                    questionText = `${questionText}(${item.maxScore}分)`;
                                }
                                return questionText;
                            }).join('、')}。</p>
                        </div>
                        
                        <div class="suggestion-item">
                            <h5>优化时间分配</h5>
                            <p>根据各科目表现，合理调整学习时间分配，对表现较弱的科目增加投入，同时保持优势科目的水平。</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // 更新概述容器
    summaryContainer.innerHTML = summaryHTML;
}

/**
 * 查找学生ID列的索引
 * @param {Array} headers - 表头行
 * @returns {number} 学生ID列的索引，如果未找到则返回-1
 */
function findStudentIdColumnIndex(headers) {
    return headers.findIndex(header => 
        typeof header === 'string' && (
            header.trim().toLowerCase() === '学号' || 
            header.trim().toLowerCase() === 'id' || 
            header.trim().toLowerCase() === '序号' || 
            header.trim().toLowerCase() === 'no' ||
            header.trim().toLowerCase() === 'no.'
        )
    );
}

/**
 * 查找学生姓名列的索引
 * @param {Array} headers - 表头行
 * @returns {number} 学生姓名列的索引，如果未找到则返回-1
 */
function findStudentNameColumnIndex(headers) {
    return headers.findIndex(header => 
        typeof header === 'string' && (
            header.trim().toLowerCase() === '姓名' || 
            header.trim().toLowerCase() === 'name' ||
            header.trim().toLowerCase() === '名字'
        )
    );
}

// 将关键函数暴露给全局环境，确保其他模块可以调用
window.showQuestionScoreAnalysisOptions = showQuestionScoreAnalysisOptions;
window.hideQuestionScoreAnalysisOptions = hideQuestionScoreAnalysisOptions;
window.loadQuestionScoreFileOptions = loadQuestionScoreFileOptions;
window.performQuestionScoreAnalysis = performQuestionScoreAnalysis;

// 在控制台输出信息，确认模块已加载
console.log('个人小题得分情况分析模块已加载'); 