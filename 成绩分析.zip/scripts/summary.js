/**
 * 成绩分析系统 - 成绩总结和建议模块
 * 用于生成成绩分析的文字总结和优化建议
 */

/**
 * 为科目生成文字总结和建议
 * @param {string} subject - 科目名称
 * @param {Array} scores - 成绩数组
 * @param {number} maxScore - 最高分
 * @param {number} minScore - 最低分
 * @param {number} avgScore - 平均分
 * @param {number} excellentCount - 优秀人数
 * @param {number} goodCount - 良好人数
 * @param {number} passCount - 及格人数
 * @param {number} failCount - 不及格人数
 * @param {number} totalCount - 总人数
 * @param {number} excellentRate - 优秀率
 * @param {number} goodRate - 良好率
 * @param {number} passRate - 及格率
 * @param {number} failRate - 不及格率
 * @param {number} passScore - 及格分数线
 * @param {number} goodScore - 良好分数线
 * @param {number} excellentScore - 优秀分数线
 * @returns {HTMLElement} 总结和建议容器
 */
function generateSubjectSummary(subject, scores, maxScore, minScore, avgScore, excellentCount, goodCount, passCount, failCount, totalCount, excellentRate, goodRate, passRate, failRate, passScore, goodScore, excellentScore) {
    // 创建总结容器
    const summaryContainer = document.createElement('div');
    summaryContainer.className = 'analysis-summary';
    
    // 计算分数差
    const scoreDiff = maxScore - minScore;
    // 计算优良率
    const excellentGoodRate = (excellentCount + goodCount) / totalCount * 100;
    
    // 创建成绩分析总结
    const summaryTitle = document.createElement('h3');
    summaryTitle.className = 'summary-title';
    summaryTitle.innerHTML = `<i class="fas fa-chart-pie"></i> ${subject}成绩分析总结`;
    
    const summaryText = document.createElement('p');
    summaryText.className = 'summary-text';
    summaryText.innerHTML = `
        本次${subject}考试共有${totalCount}名学生参加，最高分为${maxScore.toFixed(1)}分，最低分为${minScore.toFixed(1)}分，平均分为${avgScore.toFixed(1)}分，分数差为${scoreDiff.toFixed(1)}分。
        <br><br>
        优秀率为${excellentRate}%（${excellentCount}人），良好率为${goodRate}%（${goodCount}人），及格率为${passRate}%（${passCount}人），不及格率为${failRate}%（${failCount}人）。
        <br><br>
        ${generateScoreDistributionAnalysis(excellentCount, goodCount, passCount, failCount, excellentRate, passRate, avgScore)}
    `;
    
    // 创建优化建议
    const adviceTitle = document.createElement('h3');
    adviceTitle.className = 'advice-title';
    adviceTitle.innerHTML = `<i class="fas fa-lightbulb"></i> 优化建议`;
    
    const adviceList = document.createElement('ul');
    adviceList.className = 'advice-list';
    
    // 生成建议列表
    const adviceItems = generateAdvice(failCount, failRate, excellentRate, goodRate, passRate, avgScore, excellentGoodRate);
    
    adviceItems.forEach(advice => {
        const adviceItem = document.createElement('li');
        adviceItem.innerHTML = advice;
        adviceList.appendChild(adviceItem);
    });
    
    // 组装总结容器
    summaryContainer.appendChild(summaryTitle);
    summaryContainer.appendChild(summaryText);
    summaryContainer.appendChild(adviceTitle);
    summaryContainer.appendChild(adviceList);
    
    return summaryContainer;
}

/**
 * 生成分数分布分析文字
 */
function generateScoreDistributionAnalysis(excellentCount, goodCount, passCount, failCount, excellentRate, passRate, avgScore) {
    let analysis = '';
    
    // 根据分数分布情况生成分析
    if (excellentRate >= 30) {
        analysis += '从分数分布来看，班级优秀率较高，学生掌握情况良好。';
    } else if (excellentRate <= 10) {
        analysis += '从分数分布来看，班级优秀率较低，需要加强拔高训练。';
    }
    
    if (passRate >= 90) {
        analysis += '班级及格率较高，基础知识掌握较好。';
    } else if (passRate < 80) {
        analysis += '班级及格率较低，需要加强基础知识巩固。';
    }
    
    if (failCount > 0) {
        analysis += `有${failCount}名同学未能及格，需要重点关注。`;
    }
    
    if (avgScore >= 85) {
        analysis += '整体成绩表现优秀，平均分较高。';
    } else if (avgScore < 70) {
        analysis += '整体成绩表现一般，平均分偏低。';
    }
    
    if (analysis === '') {
        analysis = '整体来看，班级成绩分布较为均衡。';
    }
    
    return analysis;
}

/**
 * 生成优化建议列表
 */
function generateAdvice(failCount, failRate, excellentRate, goodRate, passRate, avgScore, excellentGoodRate) {
    const adviceList = [];
    
    // 针对不及格学生的建议
    if (failCount > 0) {
        adviceList.push(`<strong>关注不及格学生</strong>：建议重点关注${failCount}名未及格的同学，分析其薄弱环节，给予针对性辅导，帮助其尽快提升成绩。`);
    }
    
    // 针对及格率的建议
    if (passRate < 85) {
        adviceList.push('<strong>提升整体及格率</strong>：建议加强基础知识的复习和巩固，提高整体及格人数。');
    }
    
    // 针对优秀率的建议
    if (excellentRate < 20) {
        adviceList.push('<strong>提高优秀率</strong>：可适当增加难度训练，强化重点知识点，提高优秀率。');
    } else if (excellentRate >= 30) {
        adviceList.push('<strong>保持优秀水平</strong>：建议继续保持当前教学方法，并可适当增加拓展内容，进一步激发学生潜力。');
    }
    
    // 针对平均分的建议
    if (avgScore < 75) {
        adviceList.push('<strong>提升整体水平</strong>：可通过增加课堂练习、小组讨论等方式，提高整体学习效果。');
    }
    
    // 针对分数分布的建议
    if (excellentGoodRate < 50 && failRate > 15) {
        adviceList.push('<strong>分层教学</strong>：建议对学生进行分层教学，针对不同程度的学生制定不同的教学策略。');
    }
    
    // 如果建议不足3条，添加通用建议
    if (adviceList.length < 3) {
        adviceList.push('<strong>加强知识点梳理</strong>：建议对本次考试的重点、难点进行系统梳理，帮助学生建立知识体系。');
    }
    
    if (adviceList.length < 3) {
        adviceList.push('<strong>提高学习兴趣</strong>：可以通过多样化的教学方式，激发学生学习兴趣，提高学习效果。');
    }
    
    return adviceList;
}

/**
 * 生成个人成绩详情的文字总结和建议
 * @param {Object} studentData - 学生数据
 * @param {Array} subjects - 科目列表
 * @param {Object} classAvgScores - 班级平均分
 * @param {Object} maxScores - 各科目最高分
 * @param {number} totalScore - 学生总分
 * @param {number} avgScore - 学生平均分
 * @param {number} ranking - 学生排名
 * @param {number} totalStudents - 班级总人数
 * @returns {HTMLElement} 总结和建议容器
 */
function generatePersonalDetailSummary(studentData, subjects, classAvgScores, maxScores, totalScore, avgScore, ranking, totalStudents) {
    // 创建总结容器
    const summaryContainer = document.createElement('div');
    summaryContainer.className = 'analysis-summary';
    
    // 计算排名百分比
    const rankPercentage = (ranking / totalStudents * 100).toFixed(1);
    
    // 整体表现评价
    let overallPerformance = '';
    if (ranking <= Math.ceil(totalStudents * 0.1)) {
        overallPerformance = '优秀，在班级中处于领先地位';
    } else if (ranking <= Math.ceil(totalStudents * 0.30)) {
        overallPerformance = '良好，位于班级前列';
    } else if (ranking <= Math.ceil(totalStudents * 0.70)) {
        overallPerformance = '中等，接近班级平均水平';
    } else {
        overallPerformance = '需要提升，相对班级还有进步空间';
    }
    
    // 查找强势和弱势科目
    const subjectPerformance = [];
    subjects.forEach(subject => {
        const studentScore = studentData.scores[subject] || 0;
        const classAvg = classAvgScores[subject] || 0;
        const diff = studentScore - classAvg;
        const diffPercentage = (diff / classAvg * 100).toFixed(1);
        
        subjectPerformance.push({
            subject: subject,
            score: studentScore,
            diff: diff,
            diffPercentage: diffPercentage
        });
    });
    
    // 按差异排序，找出强势和弱势科目
    subjectPerformance.sort((a, b) => b.diff - a.diff);
    const strongSubjects = subjectPerformance.filter(s => s.diff > 0);
    const weakSubjects = subjectPerformance.filter(s => s.diff < 0);
    
    // 创建成绩分析总结
    const summaryTitle = document.createElement('h3');
    summaryTitle.className = 'summary-title';
    summaryTitle.innerHTML = `<i class="fas fa-chart-pie"></i> ${studentData.name}的成绩分析总结`;
    
    const summaryText = document.createElement('p');
    summaryText.className = 'summary-text';
    
    // 整体表现文字
    let summaryContent = `${studentData.name}同学的整体学习表现${overallPerformance}。总分${totalScore}分，平均分${avgScore.toFixed(1)}分，在班级中排名第${ranking}名（前${rankPercentage}%）。`;
    
    // 强势科目分析
    if (strongSubjects.length > 0) {
        summaryContent += `<br><br>强势科目：`;
        strongSubjects.forEach((item, index) => {
            if (index > 0) summaryContent += '，';
            summaryContent += `${item.subject}（高于班级平均${item.diff.toFixed(1)}分，超出${item.diffPercentage}%）`;
        });
    }
    
    // 弱势科目分析
    if (weakSubjects.length > 0) {
        summaryContent += `<br><br>有待提高的科目：`;
        weakSubjects.forEach((item, index) => {
            if (index > 0) summaryContent += '，';
            summaryContent += `${item.subject}（低于班级平均${Math.abs(item.diff).toFixed(1)}分，差距${Math.abs(item.diffPercentage)}%）`;
        });
    }
    
    summaryText.innerHTML = summaryContent;
    
    // 创建优化建议
    const adviceTitle = document.createElement('h3');
    adviceTitle.className = 'advice-title';
    adviceTitle.innerHTML = `<i class="fas fa-lightbulb"></i> 学习建议`;
    
    const adviceList = document.createElement('ul');
    adviceList.className = 'advice-list';
    
    // 生成建议列表
    const adviceItems = generatePersonalAdvice(studentData.name, strongSubjects, weakSubjects, ranking, totalStudents);
    
    adviceItems.forEach(advice => {
        const adviceItem = document.createElement('li');
        adviceItem.innerHTML = advice;
        adviceList.appendChild(adviceItem);
    });
    
    // 组装总结容器
    summaryContainer.appendChild(summaryTitle);
    summaryContainer.appendChild(summaryText);
    summaryContainer.appendChild(adviceTitle);
    summaryContainer.appendChild(adviceList);
    
    return summaryContainer;
}

/**
 * 生成个人学习建议列表
 */
function generatePersonalAdvice(studentName, strongSubjects, weakSubjects, ranking, totalStudents) {
    const adviceList = [];
    
    // 针对弱势科目的建议
    if (weakSubjects.length > 0) {
        const weakestSubject = weakSubjects[weakSubjects.length - 1];
        adviceList.push(`<strong>针对${weakestSubject.subject}学科</strong>：建议${studentName}同学加强${weakestSubject.subject}的学习，重点弥补知识点漏洞，可以通过课后习题和辅导提高该科目成绩。`);
    }
    
    // 针对强势科目的建议
    if (strongSubjects.length > 0) {
        const strongestSubject = strongSubjects[0];
        adviceList.push(`<strong>保持${strongestSubject.subject}优势</strong>：建议继续保持${strongestSubject.subject}的学习方法和热情，可以适当增加难度，挑战更高水平的题目。`);
    }
    
    // 针对排名的建议
    if (ranking <= Math.ceil(totalStudents * 0.1)) {
        adviceList.push('<strong>保持领先优势</strong>：建议在保持优秀成绩的同时，培养更广泛的学习兴趣，拓展知识面，为进一步发展奠定基础。');
    } else if (ranking <= Math.ceil(totalStudents * 0.3)) {
        adviceList.push('<strong>冲刺前列</strong>：目前成绩已经很好，建议注意查漏补缺，细化知识点，争取更进一步。');
    } else if (ranking <= Math.ceil(totalStudents * 0.7)) {
        adviceList.push('<strong>稳步提升</strong>：建议制定合理的学习计划，加强基础知识掌握，逐步提高各科成绩。');
    } else {
        adviceList.push('<strong>全面提升</strong>：建议重新调整学习方法和习惯，可以寻求老师的针对性辅导，制定基础知识巩固计划。');
    }
    
    // 针对学习方法的建议
    if (weakSubjects.length > strongSubjects.length) {
        adviceList.push('<strong>优化学习方法</strong>：建议尝试多种学习方法，找到适合自己的学习策略，提高学习效率。');
    } else if (weakSubjects.length > 0 && strongSubjects.length > 0) {
        adviceList.push('<strong>学习方法迁移</strong>：可以尝试将强势科目的学习方法迁移到其他科目，实现全面发展。');
    }
    
    return adviceList;
}

/**
 * 生成成绩总结和优化建议
 * @param {Object} studentData - 学生数据
 * @param {Array} subjects - 科目列表
 * @param {Object} classAvgScores - 班级平均分
 * @param {Object} maxScores - 最高分
 * @param {Array} allStudents - 所有学生数据
 * @param {Object} thresholds - 分数线设置(及格线、良好线、优秀线)
 * @returns {Object} 包含总结和建议的对象
 */
function generateScoreSummary(studentData, subjects, classAvgScores, maxScores, allStudents, thresholds) {
    // 获取总分、平均分和排名信息
    const totalScore = calculateTotalScore(studentData, subjects);
    const avgScore = (totalScore / subjects.length).toFixed(2);
    const ranking = calculateRanking(studentData, allStudents, subjects);
    const totalStudents = allStudents.length;
    const rankPercentage = ((ranking / totalStudents) * 100).toFixed(1);

    // 分析科目优势和劣势
    const strengthsAndWeaknesses = analyzeStrengthsAndWeaknesses(studentData, subjects, classAvgScores);
    
    // 确定学生的总体表现水平
    const overallPerformance = determineOverallPerformance(rankPercentage, strengthsAndWeaknesses);
    
    // 生成科目改进建议
    const subjectSuggestions = generateSubjectSuggestions(
        studentData, 
        subjects, 
        classAvgScores, 
        maxScores, 
        thresholds
    );
    
    // 生成学习策略建议
    const studyStrategies = generateStudyStrategies(strengthsAndWeaknesses, overallPerformance);
    
    // 整合成绩总结
    const summary = {
        overall: generateOverallSummary(studentData.name, totalScore, avgScore, ranking, totalStudents, overallPerformance),
        strengths: strengthsAndWeaknesses.strengths,
        weaknesses: strengthsAndWeaknesses.weaknesses,
        subjectSuggestions: subjectSuggestions,
        studyStrategies: studyStrategies
    };
    
    return summary;
}

/**
 * 分析学生的优势科目和劣势科目
 * @param {Object} studentData - 学生数据
 * @param {Array} subjects - 科目列表
 * @param {Object} classAvgScores - 班级平均分
 * @returns {Object} 优势和劣势科目分析
 */
function analyzeStrengthsAndWeaknesses(studentData, subjects, classAvgScores) {
    const strengths = [];
    const weaknesses = [];
    
    // 计算学生各科目与班级平均分的差距
    const scoreDifferences = {};
    subjects.forEach(subject => {
        const studentScore = studentData.scores[subject] || 0;
        const classAvg = classAvgScores[subject] || 0;
        scoreDifferences[subject] = studentScore - classAvg;
    });
    
    // 按差距排序科目
    const sortedSubjects = [...subjects].sort((a, b) => scoreDifferences[b] - scoreDifferences[a]);
    
    // 前1/3为优势科目
    const strengthCount = Math.ceil(subjects.length / 3);
    for (let i = 0; i < strengthCount && i < sortedSubjects.length; i++) {
        const subject = sortedSubjects[i];
        const diff = scoreDifferences[subject];
        if (diff > 0) { // 只有高于平均分的才算优势
            strengths.push({
                subject: subject,
                score: studentData.scores[subject] || 0,
                diffFromAvg: diff.toFixed(2)
            });
        }
    }
    
    // 后1/3为劣势科目
    const startIdx = Math.max(sortedSubjects.length - strengthCount, 0);
    for (let i = startIdx; i < sortedSubjects.length; i++) {
        const subject = sortedSubjects[i];
        const diff = scoreDifferences[subject];
        if (diff < 0) { // 只有低于平均分的才算劣势
            weaknesses.push({
                subject: subject,
                score: studentData.scores[subject] || 0,
                diffFromAvg: diff.toFixed(2)
            });
        }
    }
    
    return { strengths, weaknesses };
}

/**
 * 确定学生的总体表现水平
 * @param {number} rankPercentage - 排名百分比
 * @param {Object} strengthsAndWeaknesses - 优势和劣势科目
 * @returns {string} 表现水平描述
 */
function determineOverallPerformance(rankPercentage, strengthsAndWeaknesses) {
    // 根据排名百分比确定基础表现
    let performance = '';
    if (rankPercentage <= 10) {
        performance = '优秀';
    } else if (rankPercentage <= 30) {
        performance = '良好';
    } else if (rankPercentage <= 70) {
        performance = '中等';
    } else {
        performance = '需要加强';
    }
    
    // 根据优势和劣势科目数量调整描述
    const { strengths, weaknesses } = strengthsAndWeaknesses;
    
    if (strengths.length > 0 && weaknesses.length === 0) {
        performance += '，各科均衡发展';
    } else if (strengths.length > 0 && weaknesses.length > 0) {
        performance += '，发展不均衡';
    } else if (strengths.length === 0 && weaknesses.length > 0) {
        performance += '，需全面提升';
    }
    
    return performance;
}

/**
 * 生成科目改进建议
 * @param {Object} studentData - 学生数据
 * @param {Array} subjects - 科目列表
 * @param {Object} classAvgScores - 班级平均分
 * @param {Object} maxScores - 最高分
 * @param {Object} thresholds - 分数线设置
 * @returns {Array} 科目建议列表
 */
function generateSubjectSuggestions(studentData, subjects, classAvgScores, maxScores, thresholds) {
    const suggestions = [];
    
    subjects.forEach(subject => {
        const score = studentData.scores[subject] || 0;
        const classAvg = classAvgScores[subject] || 0;
        const maxScore = maxScores[subject] || 0;
        const diffFromAvg = score - classAvg;
        
        let suggestion = '';
        
        // 根据分数与及格线、良好线和优秀线的关系生成建议
        if (score < thresholds.passScore) {
            suggestion = `${subject}成绩未达到及格线，需要进行基础知识查漏补缺，建立学科学习兴趣，制定每日学习计划。`;
        } else if (score < thresholds.goodScore) {
            suggestion = `${subject}成绩已及格但低于良好线，建议巩固基础知识，加强关键概念理解，多做典型习题。`;
        } else if (score < thresholds.excellentScore) {
            suggestion = `${subject}成绩良好，可通过深入学习难点内容和提高解题效率，向优秀水平冲刺。`;
        } else {
            suggestion = `${subject}成绩优秀，建议保持学习状态，可尝试拓展学习和挑战更高难度的题目。`;
        }
        
        // 根据与班级平均分的差距补充建议
        if (diffFromAvg <= -10) {
            suggestion += `与班级平均分差距较大，建议及时找老师进行个别辅导。`;
        } else if (diffFromAvg < 0) {
            suggestion += `略低于班级平均水平，通过小组学习可以有效提高。`;
        } else if (diffFromAvg <= 5) {
            suggestion += `已达到班级平均水平，继续努力可以取得更好成绩。`;
        } else if (diffFromAvg <= 15) {
            suggestion += `超过班级平均水平，可以帮助其他同学，巩固自身知识。`;
        } else {
            suggestion += `大幅超过班级平均水平，可考虑参加学科竞赛拓展能力。`;
        }
        
        // 计算与最高分的差距，补充建议
        const diffFromMax = maxScore - score;
        if (diffFromMax > 20) {
            suggestion += `与最高分尚有较大差距，可分析优秀同学的学习方法。`;
        } else if (diffFromMax > 10) {
            suggestion += `接近班级最高水平，注意查缺补漏可以更进一步。`;
        } else if (diffFromMax > 0) {
            suggestion += `已接近班级最高水平，保持稳定发挥即可。`;
        } else {
            suggestion += `恭喜获得班级最高分，继续保持优秀！`;
        }
        
        suggestions.push({
            subject: subject,
            score: score,
            suggestion: suggestion
        });
    });
    
    return suggestions;
}

/**
 * 生成学习策略建议
 * @param {Object} strengthsAndWeaknesses - 优势和劣势科目
 * @param {string} overallPerformance - 总体表现
 * @returns {Array} 学习策略建议列表
 */
function generateStudyStrategies(strengthsAndWeaknesses, overallPerformance) {
    const strategies = [];
    const { strengths, weaknesses } = strengthsAndWeaknesses;
    
    // 添加时间管理建议
    if (weaknesses.length > 0) {
        strategies.push({
            title: "合理分配学习时间",
            content: `建议根据科目难度调整学习时间分配，对${weaknesses.map(w => w.subject).join('、')}等薄弱科目适当增加学习时间，确保全面发展。`
        });
    }
    
    // 添加学习方法建议
    if (overallPerformance.includes('优秀')) {
        strategies.push({
            title: "保持高效学习方法",
            content: "总结并坚持当前有效的学习方法，可尝试拓展性学习和知识融合，提高综合分析能力。"
        });
    } else if (overallPerformance.includes('良好')) {
        strategies.push({
            title: "优化学习效率",
            content: "建议采用番茄工作法提高专注度，做好课前预习和课后复习，形成良好的学习闭环。"
        });
    } else if (overallPerformance.includes('中等')) {
        strategies.push({
            title: "建立系统学习计划",
            content: "建议制定每周详细学习计划，重视基础知识点的掌握，多做针对性练习，培养解题思路。"
        });
    } else {
        strategies.push({
            title: "基础能力提升",
            content: "建议从基础知识入手，制定每日学习目标，配合错题集管理，逐步建立学科自信心。"
        });
    }
    
    // 添加学习资源建议
    strategies.push({
        title: "利用优质学习资源",
        content: "推荐使用线上学习平台辅助学习，参与小组讨论交流解题思路，必要时寻求老师个别辅导。"
    });
    
    // 添加心态建议
    strategies.push({
        title: "保持积极学习心态",
        content: "学习过程中保持积极心态，适当放松减压，将目标分解为小目标，及时给自己正面鼓励。"
    });
    
    return strategies;
}

/**
 * 生成总体成绩总结
 * @param {string} name - 学生姓名
 * @param {number} totalScore - 总分
 * @param {number} avgScore - 平均分
 * @param {number} ranking - 排名
 * @param {number} totalStudents - 总学生数
 * @param {string} performance - 表现水平
 * @returns {string} 总体总结
 */
function generateOverallSummary(name, totalScore, avgScore, ranking, totalStudents, performance) {
    const rankPercentage = ((ranking / totalStudents) * 100).toFixed(1);
    
    return `${name}同学的总成绩为${totalScore}分，平均分${avgScore}分，在班级${totalStudents}名同学中排名第${ranking}位，处于前${rankPercentage}%，总体表现${performance}。`;
}

/**
 * 渲染成绩总结和建议
 * @param {Object} summary - 成绩总结对象
 * @returns {string} HTML内容
 */
function renderScoreSummary(summary) {
    // 生成优势科目列表HTML
    let strengthsHtml = '';
    if (summary.strengths.length > 0) {
        strengthsHtml = summary.strengths.map(item => 
            `<li>${item.subject}（${item.score}分，高出平均分${item.diffFromAvg}分）</li>`
        ).join('');
    } else {
        strengthsHtml = '<li>暂无明显优势科目，建议全面提升学习能力</li>';
    }
    
    // 生成劣势科目列表HTML
    let weaknessesHtml = '';
    if (summary.weaknesses.length > 0) {
        weaknessesHtml = summary.weaknesses.map(item => 
            `<li>${item.subject}（${item.score}分，低于平均分${Math.abs(item.diffFromAvg)}分）</li>`
        ).join('');
    } else {
        weaknessesHtml = '<li>没有明显的劣势科目，各科发展均衡</li>';
    }
    
    // 生成科目建议HTML
    const subjectSuggestionsHtml = summary.subjectSuggestions.map(item => 
        `<div class="subject-suggestion">
            <h5>${item.subject}（${item.score}分）</h5>
            <p>${item.suggestion}</p>
        </div>`
    ).join('');
    
    // 生成学习策略HTML
    const studyStrategiesHtml = summary.studyStrategies.map(item => 
        `<div class="strategy-item">
            <h5><i class="fas fa-lightbulb"></i> ${item.title}</h5>
            <p>${item.content}</p>
        </div>`
    ).join('');
    
    // 拼接完整HTML
    return `
        <div class="score-summary-section">
            <div class="summary-header">
                <h4><i class="fas fa-chart-line"></i> 成绩总结分析</h4>
            </div>
            <div class="overall-summary">
                <p>${summary.overall}</p>
            </div>
            <div class="summary-details">
                <div class="summary-column">
                    <div class="summary-card strengths-card">
                        <h4><i class="fas fa-star"></i> 优势科目</h4>
                        <ul class="strengths-list">
                            ${strengthsHtml}
                        </ul>
                    </div>
                    <div class="summary-card weaknesses-card">
                        <h4><i class="fas fa-exclamation-triangle"></i> 需加强科目</h4>
                        <ul class="weaknesses-list">
                            ${weaknessesHtml}
                        </ul>
                    </div>
                </div>
            </div>
            
            <div class="subject-suggestions-section">
                <h4><i class="fas fa-chalkboard-teacher"></i> 科目具体建议</h4>
                <div class="subject-suggestions">
                    ${subjectSuggestionsHtml}
                </div>
            </div>
            
            <div class="study-strategies-section">
                <h4><i class="fas fa-brain"></i> 学习策略建议</h4>
                <div class="study-strategies">
                    ${studyStrategiesHtml}
                </div>
            </div>
        </div>
    `;
}

// 导出模块函数
window.ScoreSummary = {
    generateScoreSummary,
    renderScoreSummary,
    generateClassLevelSummary,
    renderClassLevelSummary
};

/**
 * 生成班级分数等级占比分析总结和优化建议
 * @param {Object} fileData - 文件数据
 * @param {string} subject - 科目名称
 * @param {Object} thresholds - 分数线设置
 * @param {Object} countData - 包含各等级人数的数据
 * @returns {Object} 包含总结和建议的对象
 */
function generateClassLevelSummary(fileData, subject, thresholds, countData) {
    const { excellentCount, goodCount, passCount, failCount, totalValidCount } = countData;
    
    // 计算各等级比例
    const excellentRate = (excellentCount / totalValidCount * 100).toFixed(1);
    const goodRate = (goodCount / totalValidCount * 100).toFixed(1);
    const passRate = (passCount / totalValidCount * 100).toFixed(1);
    const failRate = (failCount / totalValidCount * 100).toFixed(1);
    const excellentGoodRate = ((excellentCount + goodCount) / totalValidCount * 100).toFixed(1);
    const passRateTotal = ((excellentCount + goodCount + passCount) / totalValidCount * 100).toFixed(1);
    
    // 班级整体表现评价
    let overallPerformance = '';
    if (excellentRate >= 30) {
        overallPerformance = '优秀，班级整体水平较高';
    } else if (excellentGoodRate >= 60) {
        overallPerformance = '良好，班级整体水平较好';
    } else if (passRateTotal >= 85) {
        overallPerformance = '中等，班级整体基础较扎实';
    } else if (passRateTotal >= 70) {
        overallPerformance = '一般，班级整体水平尚需提高';
    } else {
        overallPerformance = '较弱，班级整体基础有待加强';
    }
    
    // 班级分布分析
    let distributionAnalysis = '';
    if (excellentRate >= 25) {
        distributionAnalysis += `优秀率达到${excellentRate}%，优秀生比例较高；`;
    } else if (excellentRate <= 10) {
        distributionAnalysis += `优秀率仅为${excellentRate}%，优秀生偏少；`;
    } else {
        distributionAnalysis += `优秀率为${excellentRate}%，优秀生比例适中；`;
    }
    
    if (goodRate >= 30) {
        distributionAnalysis += `良好率为${goodRate}%，良好生源充足；`;
    } else if (goodRate <= 15) {
        distributionAnalysis += `良好率仅为${goodRate}%，良好生偏少；`;
    } else {
        distributionAnalysis += `良好率为${goodRate}%，良好生适中；`;
    }
    
    if (failRate >= 20) {
        distributionAnalysis += `不及格率高达${failRate}%，需加强基础薄弱学生辅导。`;
    } else if (failRate <= 5) {
        distributionAnalysis += `不及格率仅${failRate}%，基础较扎实。`;
    } else {
        distributionAnalysis += `不及格率为${failRate}%，需关注部分学习困难学生。`;
    }
    
    // 生成优化建议
    const suggestions = [];
    
    // 根据分数分布情况生成针对性建议
    if (excellentRate < 15) {
        suggestions.push({
            title: "提高优秀率",
            content: "可通过拓展性课题和高水平习题训练，提高优秀生比例。为成绩良好的学生提供冲刺辅导，帮助他们跨入优秀行列。"
        });
    }
    
    if (goodRate < 20) {
        suggestions.push({
            title: "扩大良好学生比例",
            content: "针对处于及格线以上的学生进行针对性辅导，帮助他们掌握重要知识点，提升解题能力，向良好水平迈进。"
        });
    }
    
    if (failRate > 15) {
        suggestions.push({
            title: "降低不及格率",
            content: "建立学困生帮扶机制，一对一辅导不及格学生，重点突破基础知识难点，逐步提高其学习自信心和成绩水平。"
        });
    }
    
    // 针对分布不均匀的情况
    if (Math.abs(excellentRate - failRate) > 30) {
        suggestions.push({
            title: "均衡班级发展",
            content: "当前班级发展不均衡，建议实施分层教学策略，为不同水平的学生制定差异化教学计划，促进整体均衡发展。"
        });
    }
    
    // 针对整体情况的建议
    if (passRateTotal < 80) {
        suggestions.push({
            title: "提高整体及格率",
            content: "加强基础知识教学，多进行课堂互动和小测验，及时了解学生掌握情况，针对共性问题进行重点讲解。"
        });
    } else if (excellentGoodRate < 50) {
        suggestions.push({
            title: "提升整体学习质量",
            content: "在保证基础的同时，适当增加课程难度，引导学生进行深度思考和分析，培养解决复杂问题的能力。"
        });
    } else if (excellentRate >= 25 && failRate <= 10) {
        suggestions.push({
            title: "保持良好教学效果",
            content: "当前教学效果良好，建议持续现有教学方法，可适当增加拓展内容，进一步提高教学质量。"
        });
    }
    
    // 确保至少有三条建议
    const generalSuggestions = [
        {
            title: "优化教学方法",
            content: "根据不同学生的学习特点，采用多样化的教学方法，如小组合作学习、项目式学习等，提高学生参与度和学习效果。"
        },
        {
            title: "加强能力培养",
            content: "在知识教学的基础上，加强学生的思维能力、分析能力和解决问题能力的培养，提高学生的综合素质。"
        },
        {
            title: "建立评价反馈机制",
            content: "定期进行阶段性测试和评估，及时了解学生学习进展，给予针对性的反馈和指导，帮助学生改进学习方法。"
        }
    ];
    
    // 如果建议不足三条，添加通用建议
    while (suggestions.length < 3) {
        if (generalSuggestions.length > 0) {
            suggestions.push(generalSuggestions.shift());
        } else {
            break;
        }
    }
    
    return {
        className: fileData.class || '未知班级',
        examName: fileData.name || '未知考试',
        subject: subject,
        thresholds: thresholds,
        stats: {
            excellentCount,
            goodCount,
            passCount,
            failCount,
            totalValidCount,
            excellentRate,
            goodRate,
            passRate,
            failRate,
            excellentGoodRate,
            passRateTotal
        },
        overallPerformance,
        distributionAnalysis,
        suggestions
    };
}

/**
 * 渲染班级分数等级占比分析总结和建议
 * @param {Object} summary - 班级分数等级占比分析总结对象
 * @returns {string} HTML内容
 */
function renderClassLevelSummary(summary) {
    // 生成建议列表HTML
    const suggestionsHtml = summary.suggestions.map(item => 
        `<div class="strategy-item">
            <h5><i class="fas fa-lightbulb"></i> ${item.title}</h5>
            <p>${item.content}</p>
        </div>`
    ).join('');
    
    // 拼接完整HTML
    return `
        <div class="score-summary-section class-level-summary">
            <div class="summary-header">
                <h4><i class="fas fa-chart-pie"></i> ${summary.className} ${summary.subject}成绩等级分布分析</h4>
            </div>
            <div class="overall-summary">
                <p>${summary.examName}中，${summary.className}在${summary.subject}科目的总体表现${summary.overallPerformance}。</p>
                <p>${summary.distributionAnalysis}</p>
                <p>分数线设置：优秀≥${summary.thresholds.excellentScore}分，良好≥${summary.thresholds.goodScore}分，及格≥${summary.thresholds.passScore}分。</p>
            </div>
            
            <div class="distribution-stats">
                <div class="stats-card">
                    <div class="stat-item excellent">
                        <span class="stat-label">优秀</span>
                        <span class="stat-value">${summary.stats.excellentCount}人 (${summary.stats.excellentRate}%)</span>
                    </div>
                    <div class="stat-item good">
                        <span class="stat-label">良好</span>
                        <span class="stat-value">${summary.stats.goodCount}人 (${summary.stats.goodRate}%)</span>
                    </div>
                    <div class="stat-item pass">
                        <span class="stat-label">及格</span>
                        <span class="stat-value">${summary.stats.passCount}人 (${summary.stats.passRate}%)</span>
                    </div>
                    <div class="stat-item fail">
                        <span class="stat-label">不及格</span>
                        <span class="stat-value">${summary.stats.failCount}人 (${summary.stats.failRate}%)</span>
                    </div>
                </div>
                <div class="composite-stats">
                    <p>优良率：${summary.stats.excellentGoodRate}%</p>
                    <p>及格率：${summary.stats.passRateTotal}%</p>
                </div>
            </div>
            
            <div class="optimization-suggestions-section">
                <h4><i class="fas fa-brain"></i> 优化建议</h4>
                <div class="optimization-suggestions">
                    ${suggestionsHtml}
                </div>
            </div>
        </div>
    `;
}

/**
 * 生成跨班级平均分对比分析的智能总结和优化建议
 * @param {Object} averageScores - 各班级各科目平均分数据，格式为: { 班级: { 科目: 平均分 } }
 * @param {string} selectedSubject - 选中的科目，如果为'all'表示分析全部科目
 * @returns {HTMLElement} 包含总结和建议的DOM元素
 */
function generateCrossClassAverageAnalysisSummary(averageScores, selectedSubject) {
    // 创建总结容器
    const summaryContainer = document.createElement('div');
    summaryContainer.className = 'cross-class-analysis-summary';
    
    // 添加标题
    const summaryTitle = document.createElement('h3');
    summaryTitle.className = 'summary-title';
    summaryTitle.innerHTML = `<i class="fas fa-chart-pie"></i> 跨班级平均分对比分析总结`;
    summaryContainer.appendChild(summaryTitle);
    
    // 准备数据分析
    const classNames = Object.keys(averageScores);
    if (classNames.length === 0) {
        const noDataMsg = document.createElement('p');
        noDataMsg.className = 'summary-text';
        noDataMsg.textContent = '没有足够的数据进行分析';
        summaryContainer.appendChild(noDataMsg);
        return summaryContainer;
    }
    
    // 判断是分析单一科目还是全部科目
    if (selectedSubject !== 'all') {
        // 单科目分析
        const summary = analyzeOneSubjectAcrossClasses(averageScores, selectedSubject);
        summaryContainer.appendChild(renderCrossClassSingleSubjectSummary(summary));
    } else {
        // 全部科目分析
        const summary = analyzeAllSubjectsAcrossClasses(averageScores);
        summaryContainer.appendChild(renderCrossClassAllSubjectsSummary(summary));
    }
    
    // 添加优化建议
    const adviceTitle = document.createElement('h3');
    adviceTitle.className = 'advice-title';
    adviceTitle.innerHTML = `<i class="fas fa-lightbulb"></i> 教学优化建议`;
    summaryContainer.appendChild(adviceTitle);
    
    // 生成建议列表
    const adviceList = document.createElement('ul');
    adviceList.className = 'advice-list';
    
    // 获取建议内容
    const adviceItems = generateCrossClassAdvice(averageScores, selectedSubject);
    
    // 添加建议项
    adviceItems.forEach(advice => {
        const li = document.createElement('li');
        li.innerHTML = advice;
        adviceList.appendChild(li);
    });
    
    summaryContainer.appendChild(adviceList);
    
    return summaryContainer;
}

/**
 * 分析单一科目在不同班级间的表现
 * @param {Object} averageScores - 各班级各科目平均分数据
 * @param {string} subject - 科目名称
 * @returns {Object} 分析结果摘要
 */
function analyzeOneSubjectAcrossClasses(averageScores, subject) {
    const classNames = Object.keys(averageScores);
    const scoresData = [];
    
    // 收集各班级该科目的平均分
    classNames.forEach(className => {
        if (averageScores[className][subject] !== undefined) {
            scoresData.push({
                className: className,
                score: averageScores[className][subject]
            });
        }
    });
    
    // 如果没有数据，返回空结果
    if (scoresData.length === 0) {
        return {
            subject: subject,
            hasData: false
        };
    }
    
    // 按分数排序（从高到低）
    scoresData.sort((a, b) => b.score - a.score);
    
    // 计算总体平均分
    const totalAverage = scoresData.reduce((sum, item) => sum + item.score, 0) / scoresData.length;
    
    // 计算最高和最低分
    const highestScore = scoresData[0];
    const lowestScore = scoresData[scoresData.length - 1];
    
    // 计算分数差值
    const scoreDifference = highestScore.score - lowestScore.score;
    
    // 计算与平均值的差异
    scoresData.forEach(item => {
        item.diffFromAvg = item.score - totalAverage;
        item.diffPercentage = (item.diffFromAvg / totalAverage * 100).toFixed(1);
    });
    
    // 分为表现优秀和需要提升的班级
    const excellentClasses = scoresData.filter(item => item.diffFromAvg > 0);
    const improvingClasses = scoresData.filter(item => item.diffFromAvg < 0);
    
    // 分析表现差异大小
    let performanceVariation = '中等';
    if (scoreDifference > 15) {
        performanceVariation = '较大';
    } else if (scoreDifference < 5) {
        performanceVariation = '较小';
    }
    
    return {
        subject: subject,
        hasData: true,
        classesData: scoresData,
        totalAverage: totalAverage,
        highestScore: highestScore,
        lowestScore: lowestScore,
        scoreDifference: scoreDifference,
        excellentClasses: excellentClasses,
        improvingClasses: improvingClasses,
        performanceVariation: performanceVariation
    };
}

/**
 * 分析全部科目在不同班级间的表现
 * @param {Object} averageScores - 各班级各科目平均分数据
 * @returns {Object} 分析结果摘要
 */
function analyzeAllSubjectsAcrossClasses(averageScores) {
    const classNames = Object.keys(averageScores);
    
    // 收集所有科目
    const allSubjects = new Set();
    classNames.forEach(className => {
        Object.keys(averageScores[className]).forEach(subject => {
            allSubjects.add(subject);
        });
    });
    
    const subjects = Array.from(allSubjects);
    
    // 各班级总体表现
    const classPerformance = {};
    
    // 初始化各班级的总分和科目数量
    classNames.forEach(className => {
        classPerformance[className] = {
            totalScore: 0,
            subjectCount: 0,
            averageScore: 0,
            strongSubjects: [],
            weakSubjects: []
        };
    });
    
    // 分析每个科目
    const subjectsAnalysis = {};
    subjects.forEach(subject => {
        // 收集该科目各班级的平均分
        const scoresForSubject = [];
        let validClassCount = 0;
        let totalScore = 0;
        
        classNames.forEach(className => {
            if (averageScores[className][subject] !== undefined) {
                scoresForSubject.push({
                    className: className,
                    score: averageScores[className][subject]
                });
                totalScore += averageScores[className][subject];
                validClassCount++;
                
                // 更新班级总分和科目数
                classPerformance[className].totalScore += averageScores[className][subject];
                classPerformance[className].subjectCount++;
            }
        });
        
        if (validClassCount > 0) {
            // 计算该科目的平均分
            const subjectAverage = totalScore / validClassCount;
            
            // 保存科目分析
            subjectsAnalysis[subject] = {
                average: subjectAverage,
                classScores: scoresForSubject
            };
            
            // 更新各班级的强弱科目
            scoresForSubject.forEach(item => {
                const diff = item.score - subjectAverage;
                
                if (diff > 0) {
                    classPerformance[item.className].strongSubjects.push({
                        subject: subject,
                        score: item.score,
                        diff: diff,
                        diffPercentage: (diff / subjectAverage * 100).toFixed(1)
                    });
                } else if (diff < 0) {
                    classPerformance[item.className].weakSubjects.push({
                        subject: subject,
                        score: item.score,
                        diff: diff,
                        diffPercentage: (diff / subjectAverage * 100).toFixed(1)
                    });
                }
            });
        }
    });
    
    // 计算各班级平均分
    classNames.forEach(className => {
        if (classPerformance[className].subjectCount > 0) {
            classPerformance[className].averageScore = 
                classPerformance[className].totalScore / classPerformance[className].subjectCount;
            
            // 排序强弱科目（按差异大小）
            classPerformance[className].strongSubjects.sort((a, b) => Math.abs(b.diff) - Math.abs(a.diff));
            classPerformance[className].weakSubjects.sort((a, b) => Math.abs(b.diff) - Math.abs(a.diff));
        }
    });
    
    // 班级平均分排名
    const classAverages = [];
    classNames.forEach(className => {
        if (classPerformance[className].subjectCount > 0) {
            classAverages.push({
                className: className,
                averageScore: classPerformance[className].averageScore
            });
        }
    });
    
    // 按平均分排序
    classAverages.sort((a, b) => b.averageScore - a.averageScore);
    
    // 计算班级间平均分差异
    let maxAvgDiff = 0;
    if (classAverages.length >= 2) {
        maxAvgDiff = classAverages[0].averageScore - classAverages[classAverages.length - 1].averageScore;
    }
    
    // 分析科目间的得分差异
    const subjectAverages = [];
    subjects.forEach(subject => {
        if (subjectsAnalysis[subject]) {
            subjectAverages.push({
                subject: subject,
                average: subjectsAnalysis[subject].average
            });
        }
    });
    
    // 按平均分排序科目
    subjectAverages.sort((a, b) => b.average - a.average);
    
    // 找出全局最好和最差科目
    const bestSubject = subjectAverages.length > 0 ? subjectAverages[0] : null;
    const worstSubject = subjectAverages.length > 0 ? subjectAverages[subjectAverages.length - 1] : null;
    
    return {
        hasData: subjects.length > 0 && classNames.length > 0,
        subjects: subjects,
        classNames: classNames,
        classPerformance: classPerformance,
        subjectsAnalysis: subjectsAnalysis,
        classAverages: classAverages,
        subjectAverages: subjectAverages,
        bestSubject: bestSubject,
        worstSubject: worstSubject,
        maxAvgDiff: maxAvgDiff
    };
}

/**
 * 渲染单科目跨班级分析总结
 * @param {Object} summary - 分析结果摘要
 * @returns {HTMLElement} 渲染后的DOM元素
 */
function renderCrossClassSingleSubjectSummary(summary) {
    const container = document.createElement('div');
    
    if (!summary.hasData) {
        const noDataMsg = document.createElement('p');
        noDataMsg.className = 'summary-text';
        noDataMsg.textContent = `没有足够的${summary.subject}科目数据进行分析`;
        container.appendChild(noDataMsg);
        return container;
    }
    
    // 创建总结文本
    const summaryText = document.createElement('p');
    summaryText.className = 'summary-text';
    
    let content = `
        <strong>${summary.subject}科目跨班级分析：</strong>
        所有班级该科目的平均分为${summary.totalAverage.toFixed(1)}分。
        其中${summary.highestScore.className}班成绩最好，平均分为${summary.highestScore.score.toFixed(1)}分；
        ${summary.lowestScore.className}班有提升空间，平均分为${summary.lowestScore.score.toFixed(1)}分。
        各班之间分数差异${summary.performanceVariation}，最高与最低分差${summary.scoreDifference.toFixed(1)}分。
    `;
    
    // 添加表现优秀的班级
    if (summary.excellentClasses.length > 0) {
        content += '<br><br><strong>表现优秀的班级：</strong><br>';
        summary.excellentClasses.forEach((cls, index) => {
            content += `${cls.className}（高于平均${cls.diffFromAvg.toFixed(1)}分，超出${cls.diffPercentage}%）`;
            if (index < summary.excellentClasses.length - 1) {
                content += '，';
            }
        });
    }
    
    // 添加需要提升的班级
    if (summary.improvingClasses.length > 0) {
        content += '<br><br><strong>需要提升的班级：</strong><br>';
        summary.improvingClasses.forEach((cls, index) => {
            content += `${cls.className}（低于平均${Math.abs(cls.diffFromAvg).toFixed(1)}分，差距${Math.abs(cls.diffPercentage)}%）`;
            if (index < summary.improvingClasses.length - 1) {
                content += '，';
            }
        });
    }
    
    summaryText.innerHTML = content;
    container.appendChild(summaryText);
    
    return container;
}

/**
 * 渲染全科目跨班级分析总结
 * @param {Object} summary - 分析结果摘要
 * @returns {HTMLElement} 渲染后的DOM元素
 */
function renderCrossClassAllSubjectsSummary(summary) {
    const container = document.createElement('div');
    
    if (!summary.hasData) {
        const noDataMsg = document.createElement('p');
        noDataMsg.className = 'summary-text';
        noDataMsg.textContent = '没有足够的数据进行分析';
        container.appendChild(noDataMsg);
        return container;
    }
    
    // 创建总结文本
    const summaryText = document.createElement('p');
    summaryText.className = 'summary-text';
    
    // 基本情况总结
    let content = `<strong>跨班级全科目总体分析：</strong>
        本次分析共包含${summary.subjects.length}个科目、${summary.classNames.length}个班级的数据。`;
    
    // 班级平均分排名
    if (summary.classAverages.length > 0) {
        content += `<br><br><strong>班级总体表现排名：</strong><br>`;
        
        summary.classAverages.forEach((cls, index) => {
            content += `${index + 1}. ${cls.className}（平均分：${cls.averageScore.toFixed(1)}分）`;
            if (index < summary.classAverages.length - 1) {
                content += '<br>';
            }
        });
        
        // 添加班级间差异分析
        if (summary.classAverages.length >= 2) {
            const topClass = summary.classAverages[0];
            const bottomClass = summary.classAverages[summary.classAverages.length - 1];
            
            content += `<br><br>班级间总体差异：${topClass.className}与${bottomClass.className}平均分相差${summary.maxAvgDiff.toFixed(1)}分`;
            
            if (summary.maxAvgDiff > 10) {
                content += '，差异较大，需要关注教学均衡性';
            } else if (summary.maxAvgDiff < 5) {
                content += '，差异较小，各班教学水平均衡';
            } else {
                content += '，差异适中';
            }
        }
    }
    
    // 科目整体表现分析
    if (summary.subjectAverages.length > 0) {
        content += `<br><br><strong>科目整体表现：</strong><br>`;
        
        if (summary.bestSubject && summary.worstSubject) {
            content += `所有班级在${summary.bestSubject.subject}科目上表现最好（平均${summary.bestSubject.average.toFixed(1)}分），
                       在${summary.worstSubject.subject}科目上有提升空间（平均${summary.worstSubject.average.toFixed(1)}分）。`;
        }
    }
    
    // 各班级的强弱科目分析
    if (summary.classNames.length > 0) {
        content += `<br><br><strong>各班级强弱科目分析：</strong><br>`;
        
        summary.classNames.forEach(className => {
            const perf = summary.classPerformance[className];
            
            if (perf.subjectCount > 0) {
                content += `${className}：`;
                
                // 强项科目
                if (perf.strongSubjects.length > 0) {
                    content += `强项是${perf.strongSubjects[0].subject}（高出平均${perf.strongSubjects[0].diff.toFixed(1)}分）`;
                    
                    if (perf.strongSubjects.length > 1) {
                        content += `和${perf.strongSubjects[1].subject}（高出平均${perf.strongSubjects[1].diff.toFixed(1)}分）`;
                    }
                }
                
                // 弱项科目
                if (perf.weakSubjects.length > 0) {
                    content += `；需要提升的是${perf.weakSubjects[0].subject}（低于平均${Math.abs(perf.weakSubjects[0].diff).toFixed(1)}分）`;
                    
                    if (perf.weakSubjects.length > 1) {
                        content += `和${perf.weakSubjects[1].subject}（低于平均${Math.abs(perf.weakSubjects[1].diff).toFixed(1)}分）`;
                    }
                }
                
                content += '<br>';
            }
        });
    }
    
    summaryText.innerHTML = content;
    container.appendChild(summaryText);
    
    return container;
}

/**
 * 生成跨班级分析的优化建议
 * @param {Object} averageScores - 各班级各科目平均分数据
 * @param {string} selectedSubject - 选中的科目
 * @returns {Array} 建议列表
 */
function generateCrossClassAdvice(averageScores, selectedSubject) {
    const advice = [];
    const classNames = Object.keys(averageScores);
    
    if (classNames.length === 0) {
        return ['需要更多班级数据才能生成有效建议'];
    }
    
    // 单科目分析
    if (selectedSubject !== 'all') {
        const summary = analyzeOneSubjectAcrossClasses(averageScores, selectedSubject);
        
        if (!summary.hasData) {
            return [`没有足够的${selectedSubject}科目数据来生成建议`];
        }
        
        // 差异化教学建议
        if (summary.scoreDifference > 10) {
            advice.push(`<strong>教学资源调配</strong>：${selectedSubject}科目在不同班级之间差异较大，建议在教学资源配置上向${summary.lowestScore.className}等班级倾斜，加强薄弱班级的教学支持。`);
        }
        
        // 针对最高分班级的建议
        advice.push(`<strong>保持优势</strong>：${summary.highestScore.className}在${selectedSubject}科目表现优秀，可以探索其教学方法和经验，在教研活动中分享成功教学策略。`);
        
        // 针对最低分班级的建议
        advice.push(`<strong>针对性提升</strong>：${summary.lowestScore.className}在${selectedSubject}科目有提升空间，建议针对该班级进行${selectedSubject}知识点的专项诊断，找出学生普遍存在的薄弱环节。`);
        
        // 共性问题建议
        advice.push(`<strong>共同提高</strong>：建议组织跨班级的${selectedSubject}学科教研活动，促进教师间的经验交流，统一教学进度与重难点把握。`);
        
        // 根据差异大小添加额外建议
        if (summary.performanceVariation === '较大') {
            advice.push(`<strong>均衡发展</strong>：各班级在${selectedSubject}科目上差异明显，可考虑开展"名师带教"活动，促进教师专业化成长，缩小班级间差距。`);
        } else if (summary.performanceVariation === '较小') {
            advice.push(`<strong>整体提升</strong>：各班级在${selectedSubject}科目上表现比较接近，可以设计统一的提升计划，共同提高整体教学质量。`);
        }
    } 
    // 全科目分析
    else {
        const summary = analyzeAllSubjectsAcrossClasses(averageScores);
        
        if (!summary.hasData) {
            return ['没有足够的数据来生成建议'];
        }
        
        // 整体教学建议
        advice.push(`<strong>教学均衡性</strong>：建议关注班级间的整体差异，优化教师配置和教学资源分配，促进教学均衡发展。特别是加强对排名靠后班级的教学支持。`);
        
        // 针对最佳科目的建议
        if (summary.bestSubject) {
            advice.push(`<strong>推广成功经验</strong>：所有班级在${summary.bestSubject.subject}科目上普遍表现较好，建议总结该科目的教学经验和方法，并推广到其他学科。`);
        }
        
        // 针对最弱科目的建议
        if (summary.worstSubject) {
            advice.push(`<strong>加强薄弱学科</strong>：${summary.worstSubject.subject}是多数班级的薄弱科目，建议组织专题教研，邀请专家指导，系统提升该学科的教学水平。`);
        }
        
        // 针对表现最好班级的建议
        if (summary.classAverages.length > 0) {
            const topClass = summary.classAverages[0];
            advice.push(`<strong>分享优秀经验</strong>：${topClass.className}在多个科目上表现优秀，建议组织该班主任和任课教师分享班级管理和教学方法，促进教师间的学习交流。`);
        }
        
        // 针对特色发展的建议
        advice.push(`<strong>因材施教</strong>：不同班级有各自的学科优势和特点，建议在保证全面发展的基础上，鼓励各班发挥特长，形成教学特色。可考虑举办多样化的学科竞赛和活动，激发学生的兴趣和潜能。`);
        
        // 教学质量监控建议
        advice.push(`<strong>常态化监测</strong>：建议建立定期的跨班级成绩分析机制，及时发现问题并调整教学策略，促进各班级和各学科的均衡发展。`);
    }
    
    return advice;
} 